/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bmp.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amaaiza <amaaiza@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/14 16:21:19 by otaouil           #+#    #+#             */
/*   Updated: 2021/11/11 05:24:14 by amaaiza          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/cub3d.h"

extern struct s_all	data;
void ft_drawsquare(int x, int y,int color)
{
	
	int xfin;
	int yfin;
	int x1;
	int y1;
	x1 = x * 10;
	y1 = y * 10; 
	xfin = x1 + 10;
	yfin = y1 + 10;
	while(y1 < yfin)
	{
		x1 = x * 10;
		while(x1 < xfin)
		{
				my_mlx_pixel_put(x1,y1,color);
				//printf("x1 :%d \n y1 = %d\n",x1,y1);
				x1++;
		}
		y1++;
	}
	

}
void ft_drawplayer(int x,int y,int color)
{
	int xfin = x + 5;
	int yfin = y + 5;
	int x1 = x;
	int y1 = y; 
	while(y1 < yfin)
	{
		x1 = x ;
		while(x1 < xfin)
		{
				my_mlx_pixel_put(x1,y1,color);
				//printf("x1 :%d \n y1 = %d\n",x1,y1);
				x1++;
		}
		y1++;
	}
	
}
void ft_minimap(void)
{

	int xmap = 0;
	int ymap = 0;
	int xp;
	int yp;
	xp = (data.ply.x / data.map.ts * 10);//+ (int)data.ply.x % data.map.ts;
	yp = (data.ply.y / data.map.ts * 10); //+ (int)data.ply.y % data.map.ts;
	while(ymap <= data.map.y - 1)
	{
		xmap = 0;
		while(xmap <= data.map.x - 1)
		{
			//printf("ymap[%d] xmap[%d], datam[%c] \n",ymap,xmap,data.map.tab[ymap][xmap]);
			if(data.map.tab[ymap][xmap] == '1')
				ft_drawsquare(xmap,ymap,BLACK);
			if(data.map.tab[ymap][xmap] == '2')
				ft_drawsquare(xmap,ymap,BLUE);
			//printf("px[%d] py[%d]\n",xp,yp);
			//printf("mx[%d] my[%d]\n",xmap,ymap);
			ft_drawplayer(xp,yp,RED);
			xmap++;
		}
		ymap++;
	}
}
int		ft_dynamic(void)
{
	mlx_hook(data.win.ptr, 17, 1L << 2, ft_close, &data);
	mlx_hook(data.win.ptr, 2 , 0, ft_press, &data);
	
	mlx_hook(data.win.ptr, 3, 0, ft_unpress, &data);
	mlx_hook(data.win.ptr, 5, (1L << 3), mouseend, &data);
	mlx_mouse_hook(data.win.ptr, mousemove, &data);
	ft_draw();
	ft_minimap();
	mlx_put_image_to_window(data.mlx.ptr, data.win.ptr, data.img.ptr, 0, 0);
	free(data.img.ptr);
	free(data.img.adr);
	return (0);
}

void	bitmap_header(int fd)
{
	int			file_size;
	int			ofbits;

	ofbits = 54;
	file_size = ofbits + (data.win.y * data.win.x * 4);
	write(fd, "BM", 2);
	write(fd, &file_size, 4);
	write(fd, "\0\0\0\0", 4);
	write(fd, &ofbits, 4);
}

void	dib_header(int fd)
{
	int			bsize;
	int			biplan;
	int			imagesize;
	int			i;
	int			bpp;

	i = 16;
	bpp = 32;
	bsize = 40;
	biplan = 1;
	imagesize = (data.win.y * data.win.x);
	write(fd, &bsize, 4);
	write(fd, &data.win.x, 4);
	write(fd, &data.win.y, 4);
	write(fd, &biplan, 2);
	write(fd, &bpp, 2);
	write(fd, "\0\0\0\0", 4);
	write(fd, &imagesize, 4);
	while (i--)
		write(fd, "\0", 1);
}

void	fill_bmp(int *i, int fd)
{
	int			x;
	int			y;

	y = data.win.y;
	while (--y > 0)
	{
		x = -1;
		while (++x < data.win.x)
		{
			write(fd, &i[y * data.win.x + x], 3);
			write(fd, "\0", 1);
		}
	}
}

int		ft_bitmap(t_all s)
{
	int			fd;
	int			winb;

	winb = ((s.win.x * 24 + 31) / 32) * 4;
	ft_draw();
	fd = open("bitmap.bmp", O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU);
	bitmap_header(fd);
	dib_header(fd);
	fill_bmp((int*)data.img.adr, fd);
	close(fd);
	free(data.img.ptr);
	free(data.img.adr);
	ft_close(&data, 0);
	return (1);
}
